# Completed RIOA Brief Examples
## Health & Wellness Brands — Reference for static-ad-generation skill

---

## EXAMPLE 1: NOVA Creatine Monohydrate

### RIOA Research Brief

**Brand:** NOVA
**Product:** Creatine Monohydrate (Micronized)
**Category:** Sports Supplement
**Platform:** Instagram Feed
**Market:** India — Metro + Tier 2

---

#### R — READER

| Dimension | Detail |
|---|---|
| **Demographics** | Male, 18–28, gym-going, college student or early career, metro + tier 2 India |
| **Desires** | Build visible muscle, get stronger, look athletic, be taken seriously at the gym |
| **Notions** | "Creatine might be unsafe" / "I need to load it" / "All brands are the same" |
| **Characteristics** | Watches fitness YouTube/Reels, follows Indian fitness influencers, price-conscious, reads labels |
| **Identity** | Wants to be seen as "serious about fitness" not just a casual gym-goer |
| **Current Frustration** | Training 3-4x/week for months with minimal visible results. Feels like effort isn't paying off. |
| **Core Objection** | "I don't know if this brand is legit / if creatine will actually work for me" |

---

#### I — IDENTIFICATION & ANGLE

| Dimension | Detail |
|---|---|
| **Reader Self-Image** | "Dedicated gym-goer who hasn't cracked the code yet" |
| **Best Creative Angle** | "The missing piece isn't effort — it's recovery nutrition" |
| **Emotional Trigger** | Frustration (effort without results) → Hope (finally understanding why) |
| **Tone Register** | Direct, peer-to-peer, slightly educational, Hinglish-ready |

---

#### O — OFFER

| Dimension | Detail |
|---|---|
| **Core Offer** | 500g Pure Micronized Creatine Monohydrate |
| **Price / Deal** | Rs 999 (20% off regular Rs 1,249) + free delivery above Rs 499 |
| **Guarantee** | 30-day money-back |
| **Proof Stack** | 4.9 stars, 12,000+ reviews, FSSAI certified, third-party tested |
| **Unique Mechanism** | Micronized particles = 3x faster cell absorption, no loading phase needed |
| **Differentiator** | Transparent label, zero fillers, clinically studied 5g dose, no bloating |

---

#### A — ACTION

| Dimension | Detail |
|---|---|
| **Desired Action** | Click to product page / Buy Now |
| **CTA Copy Direction** | Direct + slightly urgent ("Get Yours Today" / "Start Now") |
| **Funnel Stage** | Cold (unaware/problem aware) → Warm (solution/product aware) |
| **Landing Destination** | Product page with reviews above fold |

---

#### AWARENESS × SOPHISTICATION

```
India Creatine Market Position: Sophistication L3-L4
Most campaigns should target: Problem Aware → Solution Aware

Winning formats for NOVA at this position:
  L3: Mechanism Education (explain micronization)
  L3: Us vs Them (compare to cheap brands)
  L4: Testimonial (real buyer, specific result)
  L4: Trust + Guarantee (FSSAI + 30-day)
```

---

## EXAMPLE 2: SHUDH Himalayan Shilajit

### RIOA Research Brief

**Brand:** SHUDH
**Product:** Pure Himalayan Shilajit Resin
**Category:** Ayurvedic Supplement / Men's Wellness
**Platform:** Instagram + Facebook Feed
**Market:** India — Urban Male 30-50

---

#### R — READER

| Dimension | Detail |
|---|---|
| **Demographics** | Male, 30–50, professional / business owner / fitness-conscious, urban India |
| **Desires** | Return to the energy levels of their 20s. Sharper focus, stronger drive, better sleep. |
| **Notions** | "Shilajit might be fake" / "It's just a traditional thing with no science" / "I've tried ashwagandha and it didn't work" |
| **Characteristics** | Reads health content, researches before buying, skeptical of supplement industry, values tradition but wants scientific backing |
| **Identity** | "Man who takes his health seriously and doesn't settle for average" |
| **Current Frustration** | Tried multiple supplements (ashwagandha, multivitamins, testosterone boosters) — none worked meaningfully. Chalking it up to "just aging." |
| **Core Objection** | "How do I know this is real Shilajit and not adulterated powder?" |

---

#### I — IDENTIFICATION & ANGLE

| Dimension | Detail |
|---|---|
| **Reader Self-Image** | "Discerning man who doesn't fall for hype — but is open to what actually works" |
| **Best Creative Angle** | "Ancient Himalayan remedy, modern scientific validation, zero compromise on purity" |
| **Emotional Trigger** | Pride (being the man who figured it out) + Fear (slowly declining without realizing it) |
| **Tone Register** | Authoritative, educational, reverent of tradition, premium |

---

#### O — OFFER

| Dimension | Detail |
|---|---|
| **Core Offer** | 30g Pure Himalayan Shilajit Resin in amber glass jar |
| **Price / Deal** | Rs 1,299 (original Rs 1,799) + free wooden spoon + batch lab report QR |
| **Guarantee** | 60-day full refund, zero questions |
| **Proof Stack** | 4.8 stars, 9,400+ reviews, AYUSH compliant, heavy metal tested, batch lab certificate |
| **Unique Mechanism** | Pure resin form keeps fulvic acid matrix intact → 85+ ionic minerals delivered at cellular level → mitochondrial function restored |
| **Differentiator** | Only brand that publishes batch-level lab reports via QR code on every jar. Resin form, not powder. Verified 16,000ft altitude sourcing. |

---

#### A — ACTION

| Dimension | Detail |
|---|---|
| **Desired Action** | Click to product page / Subscribe to Protocol |
| **CTA Copy Direction** | Exclusive / confident / zero pressure ("Get SHUDH Resin" / "Start Your 60 Days") |
| **Funnel Stage** | Cold (unaware/problem aware) → Warm retargeting (product aware) |
| **Landing Destination** | Product page with lab report access + reviews |

---

#### AWARENESS × SOPHISTICATION

```
India Shilajit Market Position: Sophistication L2-L3 (moving toward L4)
Primary barrier: AUTHENTICITY SKEPTICISM (not awareness)

Winning formats for SHUDH at this position:
  L2: Problem → Solution (tired by 3pm → Shilajit fix)
  L2: Us vs Them (resin vs powder)
  L3: Mechanism (fulvic acid + mitochondria)
  L3: Contrarian (your grandfather didn't need an energy drink)
  L4: Authority (MD Ayurveda quote)
  L4: Trust + Lab Guarantee (batch QR + 60-day)
```

---

## COMPLETED VARIATION EXAMPLE — SHUDH, Problem Aware × L3

### Master Prompt
```
Brand: SHUDH Himalayan Shilajit
Awareness: Problem Aware
Sophistication: L3
Format: Mechanism Education
Angle: "Low energy after 30 isn't age. It's mitochondrial decline."
Emotional Trigger: Reframe (it's not aging, it's correctable)
```

### Variation 1 — Visual Style: Clinical Premium
```
VARIATION TYPE: Visual Style
FORMAT: Mechanism Education
HOOK: Reframe Stat

STRATEGIC RATIONALE:
At Problem Aware × L3, the market has heard "boosts energy" a thousand times.
The only way through is to explain WHY the problem happens at a mechanism level
— and then show how the product corrects it. The clinical aesthetic signals
scientific credibility, which is exactly the trust signal a skeptical 35-year-old
Indian professional needs before considering an Ayurvedic supplement.

HIGGSFIELD PROMPT:
Premium static ad for Himalayan Shilajit brand SHUDH. PROBLEM AWARE STAGE,
SOPHISTICATION LEVEL 3. Unique mechanism education ad. Clean warm off-white
background. Bold headline top: 'Low Energy After 30 Isn't Age. It's
Mitochondrial Decline.' Below: clean minimal scientific-style infographic
showing 3-step mechanism flow with premium icons. Step 1: 'Mitochondria
efficiency drops with age' pointing arrow to Step 2: 'ATP production falls =
less cellular energy' pointing to Step 3: 'Fulvic acid in Shilajit reactivates
mitochondrial function'. Clean accent line connectors between steps in warm gold.
Below diagram: SHUDH amber glass jar product shot on stone surface, warm
lighting. Caption: 'Ancient remedy. Modern science. Same result.' SHUDH gold
logo bottom right. Premium clinical-wellness aesthetic, editorial quality, 2k.

COPY:
  Headline: "Low Energy After 30 Isn't Age. It's Mitochondrial Decline."
  Subtext: "Fulvic acid reactivates what time depletes. Now you know why."
  CTA: "Learn How It Works →"
```

### Variation 2 — Hook Variation: Contrarian
```
VARIATION TYPE: Hook
FORMAT: Mechanism Education (same visual structure, different opening)
HOOK: Contrarian

STRATEGIC RATIONALE:
Same mechanism diagram, but opens with a provocation instead of a stat.
"Your doctor won't tell you this" creates an in-group feeling and positions
SHUDH as the brand that gives you information others withhold. Works on
the same skeptical, research-oriented buyer — but activates curiosity
rather than scientific credibility as the entry emotion.

HIGGSFIELD PROMPT:
Premium static ad for Himalayan Shilajit brand SHUDH. PROBLEM AWARE STAGE,
SOPHISTICATION LEVEL 3. Contrarian mechanism hook. Dark charcoal background,
warm amber accents. Large bold white headline top: 'What Your Doctor Won't
Explain About Your Energy After 30.' Slightly smaller gold subheading:
'It's not lifestyle. It's cellular.' Below: same clean 3-step mechanism
diagram — Mitochondrial Decline → ATP Drop → Fulvic Acid Correction —
with minimal warm gold icons on dark background. SHUDH amber jar glowing
right side with soft product halo lighting. Bottom: 'SHUDH Resin.
The mechanism that works.' Gold logo bottom left. Premium clinical-Ayurveda
design, editorial luxury, 2k.

COPY:
  Headline: "What Your Doctor Won't Explain About Your Energy After 30."
  Subtext: "It's not lifestyle. It's cellular. And it's correctable."
  CTA: "See the Science →"
```

### Variation 3 — Format Variation: Authority Quote
```
VARIATION TYPE: Format
FORMAT: Authority Quote (different format, same awareness stage)
HOOK: Expert Credibility

STRATEGIC RATIONALE:
Switches from education to borrowed authority. For a Problem Aware buyer
at L3 who has been burned by fake supplements before, a credentialed
Ayurvedic doctor saying "the research is compelling" provides the social
permission slip they need. The format change (diagram → expert quote)
reaches a different psychological entry point: trust via authority
rather than trust via understanding.

HIGGSFIELD PROMPT:
Premium static ad for Himalayan Shilajit brand SHUDH. PROBLEM AWARE STAGE,
SOPHISTICATION LEVEL 3. Authority proof ad with warm cream premium background.
Top: professional headshot of distinguished Indian Ayurvedic doctor, 50s,
confident, traditional yet modern appearance, clean studio lighting.
Bold quote on dark card with gold border: 'In 20 years of practice, Shilajit
remains the single most validated Rasayana for male vitality after 30.
The fulvic acid research alone is compelling.' Attribution below: 'Dr. Rajeev
Nair, MD Ayurveda, AIIMS Certified, 20 Years Practice.' Below quote: SHUDH
amber jar product shot. Trust badges row: AYUSH Compliant, Heavy Metal Tested,
Lab Certified. SHUDH gold logo bottom right. Gold accent lines throughout.
Premium authority-first design, editorial trust aesthetic, 2k.

COPY:
  Headline: "What 20 Years of Ayurvedic Practice Taught Me About Male Energy."
  Subtext: (quote carries the ad — minimal additional copy)
  CTA: "Read the Research →"
```
