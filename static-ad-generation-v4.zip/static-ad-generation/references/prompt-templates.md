# Higgsfield Prompt Templates by Format Type
## Fill-in-the-blank templates for health & wellness static ads

---

## HOW TO USE THESE TEMPLATES

Replace all `[BRACKETED]` values with brand-specific details from the RIOA brief.
Every template ends with a quality cue — never remove it.
Always add brand logo placement and color direction at the end.

---

## TEMPLATE 01 — LIFESTYLE / CURIOSITY

```
Premium static ad for [BRAND NAME]. [AWARENESS STAGE], [SOPHISTICATION LEVEL].
Cinematic lifestyle scene: [PERSON DESCRIPTION — age, gender, ethnicity, appearance]
in [ENVIRONMENT — home, gym, office, outdoors], [BODY LANGUAGE / EXPRESSION],
[LIGHTING DIRECTION — golden hour / warm morning / dramatic side light].
[EMOTIONAL ATMOSPHERE — tired, energized, calm, frustrated, confident].
Large bold [FONT STYLE] headline text overlay at [POSITION — top / center]:
'[HEADLINE COPY]'.
Minimal [FONT STYLE] subtext: '[SUBTEXT COPY]'.
Small clean [BRAND] logo [POSITION — bottom right / top left] in [COLOR].
[GRADIENT DIRECTION] gradient overlay on [POSITION — bottom third / edges].
Professional ad design, premium editorial quality, magazine-grade photography aesthetic.
```

---

## TEMPLATE 02 — PROBLEM → SOLUTION (SPLIT)

```
Premium static ad for [BRAND NAME]. [AWARENESS STAGE], [SOPHISTICATION LEVEL].
Clean [BACKGROUND COLOR] background, split layout.
Top half: [PROBLEM VISUAL — person showing pain / frustration scene],
caption above: '[PROBLEM STATEMENT]'.
Bottom half: clean product shot of [PRODUCT DESCRIPTION] on [SURFACE],
[LIGHTING DIRECTION].
[ARROW / DIVIDER] between sections pointing from problem to solution.
Bold text: '[CORE HEADLINE]'.
Subtext: '[SOLUTION HINT]'.
[BRAND] logo [POSITION]. Professional ad design, premium DTC brand aesthetic,
clean minimal layout, editorial quality.
```

---

## TEMPLATE 03 — PAIN AGITATION LIST

```
Premium static ad for [BRAND NAME]. [AWARENESS STAGE], [SOPHISTICATION LEVEL].
[DARK / LIGHT] background, [COLOR TONE] tones.
Left-aligned bold [TEXT COLOR] text with [RED / DARK] X icons stacked vertically:
'X [PAIN POINT 1]'
'X [PAIN POINT 2]'
'X [PAIN POINT 3]'
'X [PAIN POINT 4]'
'X [PAIN POINT 5]'.
Below the list: [ACCENT COLOR] divider line.
Bold [COLOR] text: '[REFRAME LINE]'.
[BRAND] logo bottom [POSITION].
Dramatic editorial lighting, premium performance brand aesthetic,
strong typographic hierarchy, editorial quality.
```

---

## TEMPLATE 04 — BENEFITS LISTICLE

```
Premium static ad for [BRAND NAME]. [AWARENESS STAGE], [SOPHISTICATION LEVEL].
Clean [BACKGROUND] background, premium [MINIMAL / BOLD] layout.
Bold headline top: '[HEADLINE — X Reasons / Benefits of / Why X]'.
Below: clean vertical checklist with [COLOR] checkmark icons:
'[BENEFIT 1]'
'[BENEFIT 2]'
'[BENEFIT 3]'
'[BENEFIT 4]'
'[BENEFIT 5]'.
Right side: premium product shot [PRODUCT DESCRIPTION], [LIGHTING].
[BRAND] [COLOR] logo [POSITION].
Luxury [CATEGORY] supplement aesthetic, editorial quality.
```

---

## TEMPLATE 05 — US VS THEM COMPARISON

```
Premium static ad for [BRAND NAME]. [AWARENESS STAGE], [SOPHISTICATION LEVEL].
Clean [BACKGROUND] background, two-column grid layout.
Left column header '[COMPETITOR LABEL]' with [RED] label,
right column '[BRAND NAME]' with [GREEN / GOLD] label.
Row comparisons with X and checkmark icons:
'[COMPETITOR WEAKNESS 1] vs [BRAND STRENGTH 1]'
'[COMPETITOR WEAKNESS 2] vs [BRAND STRENGTH 2]'
'[COMPETITOR WEAKNESS 3] vs [BRAND STRENGTH 3]'
'[COMPETITOR WEAKNESS 4] vs [BRAND STRENGTH 4]'
'[COMPETITOR WEAKNESS 5] vs [BRAND STRENGTH 5]'.
Bold headline top: '[HEADLINE]'.
[BRAND] product [POSITION]. [ACCENT COLOR] accent lines.
Premium comparison design, editorial quality.
```

---

## TEMPLATE 06 — MECHANISM EDUCATION / BREAKDOWN

```
Premium static ad for [BRAND NAME]. [AWARENESS STAGE], [SOPHISTICATION LEVEL].
[DARK / LIGHT] [COLOR] background, [WARM / COOL / CLINICAL] tones.
Bold headline top: '[BOLD REFRAME HEADLINE]'.
Below: clean [3/4]-step visual mechanism flow with [MINIMAL / SCIENTIFIC] icons:
Step 1: '[MECHANISM STEP 1]'
Step 2: '[MECHANISM STEP 2]'
Step 3: '[MECHANISM STEP 3]'.
[BRAND] product [DESCRIPTION] [POSITION].
Caption: '[CLOSING LINE]'.
[BRAND] [COLOR] logo [POSITION]. Clean accent line design,
premium [CLINICAL / SCIENTIFIC / AYURVEDIC] aesthetic, editorial quality.
```

---

## TEMPLATE 07 — AUTHORITY QUOTE

```
Premium static ad for [BRAND NAME]. [AWARENESS STAGE], [SOPHISTICATION LEVEL].
Clean [BACKGROUND] premium background.
Top: professional headshot of [EXPERT DESCRIPTION — doctor, coach, nutritionist],
[APPEARANCE], [ENVIRONMENT], [LIGHTING].
Bold quote overlaid on dark card: '[EXPERT QUOTE — specific, credible, not vague]'.
Attribution: '[NAME], [CREDENTIALS]'.
Below quote: [BRAND] product shot clean.
[TRUST BADGE ICONS]. [ACCENT COLOR] accents.
Premium authority-first design, editorial trust aesthetic.
```

---

## TEMPLATE 08 — TESTIMONIAL (FEATURED)

```
Premium static ad for [BRAND NAME]. [AWARENESS STAGE], [SOPHISTICATION LEVEL].
Premium [BACKGROUND] background.
Large photo of [CUSTOMER DESCRIPTION — age, gender, appearance],
[ENVIRONMENT], [EXPRESSION], [LIGHTING].
Overlaid [DARK / LIGHT] quote card with [ACCENT] border:
'[TESTIMONIAL — specific, timed, named, addresses objection]'.
Name: [CUSTOMER NAME], [CITY]. Verified [BUYER / PURCHASE] badge.
Below: [RELEVANT PROOF ELEMENT — stat, before/after numbers].
[BRAND] product [POSITION]. [ACCENT COLOR] accents.
Premium testimonial ad design, editorial quality.
```

---

## TEMPLATE 09 — BEFORE / AFTER

```
Premium static ad for [BRAND NAME]. [AWARENESS STAGE], [SOPHISTICATION LEVEL].
Split [VERTICAL / HORIZONTAL] layout.
Left side: [DESATURATED / MUTED] photo of [PERSON DESCRIPTION],
[BEFORE STATE — tired, low energy, unflattering],
label below '[BEFORE LABEL — e.g., Before BRAND. Month 1]'.
Right side: same [PERSON ARCHETYPE], [VIBRANT / SATURATED],
[AFTER STATE — confident, energized, transformed],
label '[AFTER LABEL — e.g., After BRAND. Month 3]'.
[THIN / GOLD / ACCENT] divider center with [BRAND] logo.
Bold headline top: '[TRANSFORMATION HEADLINE]'.
Bottom: [SOCIAL PROOF ELEMENT] and '[CTA]'.
Premium editorial photography split ad, [BRAND AESTHETIC] aesthetic.
```

---

## TEMPLATE 10 — TRUST + GUARANTEE

```
Premium static ad for [BRAND NAME]. [AWARENESS STAGE], [SOPHISTICATION LEVEL].
Clean [BACKGROUND] premium background.
Top center: large premium [SHAPE] badge icon with [COLOR] border,
bold text inside: '[GUARANTEE — e.g., 30-Day Full Money Back]'.
Below badge: [N] horizontal trust badges row:
'[CERT 1]', '[CERT 2]', '[CERT 3]', '[CERT 4]'.
Bold headline: '[CONFIDENCE HEADLINE]'.
Subtext: '[GUARANTEE DETAIL — specific, not vague]'.
[BRAND] product [POSITION]. [ACCENT COLOR] accent lines throughout.
Premium trust-first design, editorial quality.
```

---

## TEMPLATE 11 — DIRECT OFFER (MOST AWARE)

```
Premium static ad for [BRAND NAME]. MOST AWARE STAGE, [SOPHISTICATION LEVEL].
Clean [BACKGROUND] background.
Hero product shot of [PRODUCT DESCRIPTION] centered, [LIGHTING].
Bold [COLOR] price offer [STICKER / BADGE]: '[DISCOUNT — e.g., 20% OFF]'.
Large bold headline: '[BRAND + PRODUCT]. [OFFER HOOK]. [TIME ELEMENT].'
Clean benefit line: '[1 LINE PRODUCT SUMMARY + GUARANTEE + DELIVERY].'
Large bold CTA button in [COLOR]: '[CTA COPY] →'.
[BRAND] logo top. Bottom trust strip: '[CERT] | [CERT] | [SOCIAL PROOF]'.
Premium DTC [CATEGORY] offer ad, clean conversion-focused design,
urgency without desperation, editorial quality.
```

---

## TEMPLATE 12 — URGENCY BUNDLE

```
Premium static ad for [BRAND NAME]. MOST AWARE STAGE, [SOPHISTICATION LEVEL].
[DARK / CHARCOAL] background, [ACCENT COLOR] accents.
Bold [WHITE / LIGHT] headline: '[SCARCITY HEADLINE]'.
[BRAND] product shot center with [RED / ACCENT] '[STOCK SIGNAL — LOW STOCK / SELLING FAST]' badge.
Below: clean bundle offer box [ACCENT] border: '[BUNDLE DESCRIPTION + PRICE]'.
[OPTIONAL] subtle stock progress bar: [XX]% claimed.
CTA button [COLOR]: '[CTA COPY] →'.
[BRAND] mark top. Premium urgency design,
luxury [CATEGORY] brand aesthetic, not cheap-looking, editorial quality.
```

---

## TEMPLATE 13 — VIP / EXCLUSIVITY

```
Premium static ad for [BRAND NAME]. MOST AWARE STAGE, SOPHISTICATION LEVEL 5.
[DEEP BLACK / LUXURY] background, [GOLD / PREMIUM ACCENT] overlay.
Elegant [GOLD / ACCENT] [SERIF / ELEGANT] headline: '[EXCLUSIVITY HEADLINE]'.
Subtext [WHITE / LIGHT] font: '[MEMBERSHIP BENEFITS — specific, 3 items].'
Center: premium product shot of [PRODUCT] with [GOLD / SOFT] light [HALO / GLOW] effect.
Bottom: [EXCLUSIVE-LOOKING] membership card graphic.
CTA in [GOLD / ACCENT] button: '[MEMBERSHIP CTA] →'.
[BRAND] [COLOR] wordmark top.
Small text: '[SCARCITY SIGNAL].'
Ultra-premium luxury [CATEGORY] brand aesthetic, editorial quality.
```

---

## TEMPLATE 14 — CONTRARIAN TYPOGRAPHY

```
Premium static ad for [BRAND NAME]. [AWARENESS STAGE], [SOPHISTICATION LEVEL].
[DEEP BLACK / BOLD CONTRAST] background with subtle [ENVIRONMENT ELEMENT].
Large bold [WHITE / CONTRAST] centered typography:
'[CONTRARIAN STATEMENT — challenges a belief they hold].'
Second line smaller [ITALIC / ACCENT COLOR]: '[HOOK THAT DEEPENS THE IDEA].'
Bottom: [PRODUCT SHOT / MINIMAL PRODUCT ELEMENT].
[ACCENT COLOR] accent [LINE / ELEMENT] divider.
[BRAND] wordmark in [COLOR].
High fashion meets [CATEGORY] brand aesthetic,
editorial luxury, typographic-dominant design.
```

---

## TEMPLATE 15 — IDENTITY / COMMUNITY PROOF

```
Premium static ad for [BRAND NAME]. [AWARENESS STAGE], [SOPHISTICATION LEVEL].
Cinematic [WARM / DRAMATIC] [GROUP / SOLO] scene:
[PERSON/GROUP DESCRIPTION — demographic, attire, energy],
[ENVIRONMENT — gym, outdoors, city, home],
[LIGHTING — golden hour / morning / dramatic].
[BOLD / LARGE] text overlay: '[COMMUNITY STAT OR IDENTITY STATEMENT].'
Below [SMALLER]: '[HOOK LINE THAT CREATES BELONGING / ASPIRATION].'
[BRAND] logo [COLOR] [POSITION].
[DARK / WARM] vignette edges.
Premium editorial photography, [AUTHENTIC / ASPIRATIONAL] energy,
luxury [CATEGORY] brand aesthetic.
```
