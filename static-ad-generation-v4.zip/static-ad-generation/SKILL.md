---
name: static-ad-generation
description: >
  Health & wellness static ad image prompt generation skill. Use this AFTER static-ad-research v4 has produced a completed RIOA Research Brief. Generates a Master Prompt and multiple variation prompts (visual style, hook, format) optimised for Higgsfield image generation. Triggers when: RIOA brief is complete and user wants prompts generated, user says "generate the ads", "give me the prompts", "now generate", "create variations", "build the prompts", or when static-ad-research hands off with ✅ signal. Also triggers when user says "I want static ad prompts" and a research brief exists in conversation. NEVER run without a completed RIOA brief — if brief is missing, load static-ad-research first. Built for health, wellness, supplement, Ayurveda, fitness, and DTC brand paid social campaigns on Instagram, Facebook, and Google Display.
---

# Static Ad Generation Skill — v4

## Purpose
Transform a completed RIOA Research Brief into a **Master Prompt** and **multiple variation prompts** ready for Higgsfield. Every prompt is platform-compliant, aspect-ratio correct, strategically annotated, copy-complete, and followed by a campaign-specific iteration framework that tells the client exactly what to do after results come in.

## Prerequisites
- Completed RIOA Research Brief from `static-ad-research` v4
- Traffic type split confirmed (cold / retargeting / both)
- Platform list + aspect ratio mapping from research brief
- Page audit result + UGC status carried from research brief
- Budget tier confirmed (determines variation count)
- All ⛔ hard stops resolved or client override documented
- If brief missing → stop immediately, load `static-ad-research` first

---

## STEP 1 — PRE-GENERATION CHECKS

Run ALL three checks before writing a single prompt. Do not skip any.

### Check A — Platform Compliance Gate

```
PLATFORM COMPLIANCE GATE
━━━━━━━━━━━━━━━━━━━━━━━━
For EVERY variation, verify before writing:

Meta (Instagram/Facebook):
  □ No before/after body transformation framing
  □ No medical cure / treatment language
  □ No fear-based body image language ("ugly", "fat", "sick")
  □ Testimonials → "Results may vary" in design notes
  □ Clinical stats → "Study findings" framing, not absolute promise

Google Display:
  □ No sensational or shocking imagery direction
  □ No misleading health claim language in copy
  □ Educational framing preferred

All Platforms:
  □ No competitor brand names directly
  □ Claims match what product page can substantiate

IF any variation violates a rule:
  → Reframe angle BEFORE writing the prompt
  → Document reframe in Design Notes
  → Never output non-compliant prompt labelled "check this"
```

### Check B — Aspect Ratio Assignment (New in v4)

```
ASPECT RATIO ASSIGNMENT
━━━━━━━━━━━━━━━━━━━━━━━
Read platform list from research brief. Assign ratios:

  Instagram Feed only      → 4:5 for all prompts
  Facebook Feed only       → 1:1 for all prompts
  Instagram + Facebook     → Generate BOTH 4:5 AND 1:1 per variation
                             Label: "[Variation Name] — Instagram 4:5"
                             and:   "[Variation Name] — Facebook 1:1"
  Instagram/Facebook Story → 9:16. Note: text must stay in center-safe
                             zone (avoid top and bottom 20% of frame)
  Google Display           → Generate three sizes: 1:1, 4:3, 16:9
  Multi-platform mix       → List each platform → ratio combination
                             and generate separate prompt per ratio

IMPORTANT:
  Different ratios = different compositions, not just crops.
  A 4:5 ad has more vertical space — use it for longer text overlays.
  A 1:1 ad is square — composition must work without the extra height.
  A 9:16 story is vertical full-screen — product must be visible in
  center 60% of frame to avoid being covered by UI elements.

Single platform → assign one ratio. No extra prompts needed.
```

### Check C — Traffic Type Variation Mapping (New in v4)

```
TRAFFIC TYPE MAPPING
━━━━━━━━━━━━━━━━━━━━
Cold traffic brief   → Education-led formats. Mechanism, problem-solution,
                       curiosity, pain agitation, benefits listicle, authority.

Retargeting brief    → Conversion-led formats. Testimonial, guarantee close,
                       urgency bundle, social proof mosaic, identity retargeting,
                       VIP/exclusivity.

IF both briefs exist → Generate separate variation sets.
  Cold set:        [N] variations with education-led formats
  Retargeting set: [N] variations with conversion-led formats
  Label clearly:   "COLD TRAFFIC — [Variation Name]"
                   "RETARGETING — [Variation Name]"
  Never mix cold and retargeting formats in the same output block.

IF single traffic type → Generate one set with appropriate formats.
```

---

## STEP 2 — DETERMINE VARIATION COUNT & DISTRIBUTION

### Budget-First Rule

```
BUDGET → VARIATION COUNT
━━━━━━━━━━━━━━━━━━━━━━━━
< Rs 500/day:         2 variations
Rs 500-2,000/day:     3 variations
Rs 2,000-5,000/day:   5 variations
Rs 5,000+/day:        5-10 variations
Budget UNKNOWN:       3 variations, flag assumption

If running BOTH cold + retargeting:
  Apply budget rule to EACH set separately.
  Total variations = cold set + retargeting set.
  e.g., Rs 2,000/day split = Rs 1,000 cold + Rs 1,000 retargeting
  → 3 cold variations + 3 retargeting variations = 6 total.
```

### Distribution Table — Conflict-Resolved

```
VARIATION COUNT → DISTRIBUTION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
2 variations:  1 Visual Style + 1 Format
3 variations:  1 Visual Style + 1 Hook + 1 Format
5 variations:  1 Visual Style + 2 Hook + 2 Format
10 variations: 3 Visual Style + 4 Hook + 3 Format
25 variations: Full awareness × sophistication matrix

CONFLICT RESOLUTION RULE (permanent from v3):
  Format minimum (2 per set of 5+) ALWAYS overrides distribution table.
  If conflict: reduce Visual Style count, never reduce Format.
  Reason: Format = different cognitive decision mode.
          Visual Style = different aesthetic preference only.
  Decision mode > aesthetic preference for conversion testing.

MULTI-PLATFORM NOTE:
  If 2 aspect ratios needed (e.g., Instagram + Facebook):
  Each variation counts ONCE in distribution.
  The second ratio is a crop-adapted version, not a new variation.
  e.g., 3 variations × 2 ratios = 6 prompts total, but 3 variations.
```

---

## STEP 3 — BUILD THE MASTER PROMPT

Write this FIRST. All variations inherit from it. No placeholders allowed.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MASTER PROMPT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

BRAND:              [Brand Name]
PRODUCT:            [Product Name]
AWARENESS STAGE:    [Stage]
SOPHISTICATION:     [L1-L5]
TRAFFIC TYPE:       [Cold / Retargeting / Cold + Retargeting]
PRIMARY FORMAT:     [Winning format at this position × traffic type]
PLATFORM(S):        [List all]
ASPECT RATIO(S):    [Per platform — e.g., "Instagram: 4:5 | Facebook: 1:1"]
BUDGET TIER:        [Rs/day → N variations per set]
PAGE STATUS:        [✅ READY / ⚠️ WEAKNESS Gate N / ⛔ NOT READY Gates N,N]
UGC STATUS:         [Real quotes available / Composite / Collection brief issued]

READER (R):
  Deep Desire:        [Outcome they want — not the feature]
  Core Objection:     [Exact belief blocking purchase — in buyer's voice]
  Current Identity:   [How they see themselves right now]
  Aspired Identity:   [Who they want to become]
  Failed Attempts:    [What they tried that didn't work — specific]
  Problem Duration:   [How long — affects tone: acute vs chronic]
  Competitor Baggage: [Brands tried/rejected and why]

IDENTIFICATION & ANGLE (I):
  Creative Angle:     [Bridge from current → aspired identity via product]
  Emotional Trigger:  [ONE primary emotion — name it and why it's right]
  Tone:               [peer / authoritative / educational / contrarian]
  What to Avoid:      [Specific tones/angles that repel this buyer]

OFFER (O):
  Core Offer:         [Exact product + format + quantity]
  Differentiator:     [Verifiable claim no competitor can match]
  Mechanism:          [The HOW — not the WHAT]
  Proof Stack:        [Stars, reviews, certs, studies — exact numbers]
  Best UGC Quote:     [Exact customer quote if available — for testimonial]
  Guarantee:          [Exact terms — or ⛔ MISSING]
  Offer Gaps:         [What's weak that ads cannot fix]

ACTION (A):
  Desired Action:     [Exact next step after seeing ad]
  CTA Tone:           [urgent / soft / exclusive / curious / direct]
  Landing Situation:  [Page status + specific gates that failed]

VISUAL BRIEF:
  Hero Element:       [Person / product / scene / typography — ONE dominant]
  Color Palette:      [Exact colors — e.g., "navy blue + soft gold + white"]
  Lighting:           [Exact: golden hour / clean studio / dramatic side /
                       warm morning / soft diffused]
  Aesthetic:          [Premium editorial / bold performance / minimal clinical /
                       warm lifestyle / intelligent luxury]
  Mandatory:          [Must-appear elements with exact placement]
  Compliance:         [Platform restrictions affecting visual direction]

COPY DIRECTION:
  Headline Job:       [Psychological function — what must the headline do?]
  Headline Option A:  [Actual written copy]
  Headline Option B:  [Actual written copy]
  Headline Option C:  [Actual written copy]
  Subtext:            [Actual written copy — not a direction]
  CTA:                [Exact wording]
  Disclaimer:         [If required by platform]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## STEP 4 — CLONE ANALYSIS BLOCK (Mode B only)

Add before variations when cloning a winning ad.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CLONE ANALYSIS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Reference:          [Source — image / URL / description]
Performance Proof:  [Winning metric + duration running]
Original Audience:  [Who it targeted]

Reverse Engineering:
  Format:           [Structural format]
  Awareness Pos:    [Stage × Soph. of original]
  Hook Type:        [Opening psychological mechanism]
  Visual Strategy:  [WHY the image works — not what it shows]
  Copy Strategy:    [What the headline is doing psychologically]
  Emotional Arc:    [First impression → mid → CTA feeling]
  Why It Wins:      [Specific psychological lever — mechanistic, not vague]

Clone Strategy:
  Keep:    [Format logic, hook type, emotional arc, layout structure]
  Adapt:   [Brand identity, proof, mechanism language, cultural context]
  Upgrade: [Where original is weak — improve here specifically]
  Risk:    [What breaks when transplanting to this brand]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## STEP 5 — GENERATE VARIATION PROMPTS

Use this exact structure for EVERY variation. No exceptions. No placeholders.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VARIATION [N] — [TRAFFIC TYPE] — [TYPE]: [Short Name]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TRAFFIC TYPE:      [COLD / RETARGETING]
VARIATION TYPE:    [Visual Style / Hook / Format]
FORMAT:            [Specific: Mechanism / Testimonial / Us vs Them / etc.]
HOOK STYLE:        [Curiosity / Stat / Identity / Pain / Contrarian / Proof]
ASPECT RATIO:      [4:5 / 1:1 / 9:16 — per platform from research brief]
PLATFORM CHECK:    [Compliant ✓] or [Reframed from X to Y ✓]

STRATEGIC RATIONALE:
  Emotion:     [What emotion this triggers AND why that emotion is correct
                at this specific stage × sophistication. Not just "resonates"
                — explain the psychological reason it works HERE.]
  Mechanism:   [What cognitive process this activates in the buyer.
                What is their brain doing when it encounters this format?
                Why does this structure move them toward action?]
  Difference:  [Why this variation is MEANINGFULLY different from the others
                in this set. Different cognitive mode, not just different look.
                If two variations reach the same decision mode — that's
                duplication, not variation. Fix it.]

HIGGSFIELD IMAGE PROMPT:
[150-200 words. Visual-dominant. Zero copy text inside prompt.
 See prompt engineering rules. Count words if unsure.]

── [Platform A] [Ratio] PROMPT ──────────────────────────
[Full Higgsfield prompt for this platform/ratio]
─────────────────────────────────────────────────────────

── [Platform B] [Ratio] PROMPT (if multi-platform) ──────
[Adapted Higgsfield prompt — same strategy, composition
 adjusted for the different aspect ratio]
─────────────────────────────────────────────────────────

COPY DIRECTION:
  Headline A:   [Actual written copy — ready to use]
  Headline B:   [Actual written copy — ready to use]
  Headline C:   [Actual written copy — ready to use, or omit if 2 sufficient]
  Subtext:      [Actual written copy — not a direction to write it]
  CTA:          [Exact wording]
  Disclaimer:   [Platform-required text, e.g., "Results may vary"]

DESIGN NOTES:
  Layout:      [Specific: "Left-aligned, product bottom-right, copy top-left two-thirds"
                NOT "clean layout" or "minimal design"]
  Typography:  [Font weight + size relationship: "Bold semibold headline,
                2.5x larger than subtext, light sans-serif body text"]
  Hierarchy:   [First eye hit / Second eye hit / Third eye hit — name elements]
  Contrast:    [Explicit pair: "White text on navy — 85% contrast ratio"]
  Compliance:  [Specific compliance note for THIS variation]

UGC NOTE (if testimonial format):
  [Real quote used: "[exact quote]" from [name, city]
   OR: Composite quote — replace with real customer quote before scaling]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Design Notes Consistency Rule
Every variation's DESIGN NOTES must contain ALL FIVE elements:
Layout + Typography + Hierarchy + Contrast + Compliance.
All five. Every time. No exceptions.
Missing any element = incomplete output.

---

## STEP 6 — HIGGSFIELD PROMPT ENGINEERING RULES — v4

### Length Rule
**Hard cap: 150-200 words per image prompt.**
Recraft-v4-1 processes visual descriptions — not copy instructions.
Over 200 words dilutes model attention on visual elements.
If prompt exceeds 200 words → remove copy references first (they belong in COPY DIRECTION), then trim non-visual descriptions.
Count words when unsure. Do not estimate.

### Multi-Ratio Prompt Rule (New in v4)
When generating for 2 ratios (e.g., 4:5 + 1:1):
- 4:5 prompt: use vertical composition. Text overlays can be taller. Product can be lower in frame.
- 1:1 prompt: use square composition. Tighten the scene. Product and text must both fit without feeling cramped.
- 9:16 prompt: full vertical. Subject should be in center 60%. Keep text in center-safe zone. Bottom 20% covered by Instagram UI.
Always label which ratio each prompt is for.

### Visual Priority Rules
1. **Lighting first** — state within first 3 sentences. Model weights it heavily.
   Options: golden hour / dramatic side / clean studio / warm morning / cinematic / soft diffused
2. **Subject position** — left-aligned unless split layout required. Left-align = 23% higher engagement.
3. **Background** — never vague. "Warm cream background with subtle sage green accent" not "clean background."
4. **Human face** — include when empathy or trust is the entry emotion. Faces = 38% engagement lift.
   Skip for: type-led contrarian ads, mechanism diagrams, offer/product-only ads.
5. **Product placement** — exact position every time: hero center / bottom right / left third / floating / prop in scene.
6. **Color** — specific names. "Deep teal" not "natural tones." "Warm terracotta" not "earthy colors."

### Copy-in-Image Rules
7. **Font weight** — bold / semibold / light / serif / sans-serif. Never omit.
8. **Text placement** — exact zone: top-left third / bottom overlay / center / right column split.
9. **Text color** — explicit contrast pair: white on navy / charcoal on cream / gold on black.
10. **Gradient overlays** — direction + opacity: "Dark gradient top 80% opacity to bottom 40%" not "gradient overlay."

### Quality Signal Rules
11. **End every prompt** with one quality cue appropriate to brand aesthetic:
    "premium editorial quality" / "magazine-grade photography aesthetic" /
    "cinematic ad aesthetic" / "luxury wellness editorial quality" /
    "intelligent premium DTC aesthetic"
12. **Resolution** — always end with "2k"
13. **Banned words** — never use: beautiful, amazing, stunning, gorgeous, incredible, perfect, striking.
    These are processing noise — the model ignores them and they waste word budget.
14. **No copy text in image prompt** — no "with headline that reads X" — causes rendering failures.
    All copy goes in COPY DIRECTION section only.

### Brand Consistency Rules
15. **Logo** — specify placement every time: bottom right / top left / bottom center. "Add logo" is insufficient.
16. **Brand color** — inject into named elements: CTA bar / accent lines / badge background / border color.
17. **Certification badges** — specify size relative to other elements and exact placement.

---

## STEP 7 — VARIATION TYPE DEFINITIONS — v4

### Visual Style Variations
Same format + hook. Different aesthetic execution.
Tests which visual world resonates with audience.

| Style | Description | Best For |
|---|---|---|
| Cinematic Dark | High contrast, moody, dramatic lighting | Performance, male-skew, premium supplement |
| Clean Editorial | White/cream, minimal, DTC premium | Skincare, female-skew, clean label |
| Warm Lifestyle | Golden hour, candid human, authentic | Ayurveda, family wellness, trust-building |
| Clinical Premium | Diagrams, clean lines, lab aesthetic | Evidence-based claims, skeptical buyer |
| Bold Type-Led | Typography dominant, image minimal | Contrarian hooks, high sophistication |
| Intelligent Luxury | Navy/gold/white, editorial premium | Brain health, female professional audience |

### Hook Variations
Same format + visual direction. Different headline psychological mechanism.
Tests which emotional entry point converts.

| Hook | Mechanism | What the Brain Does |
|---|---|---|
| Curiosity | Open loop — must resolve | Compelled to keep reading |
| Stat | Hard number creates personal relevance | Forces self-assessment |
| Identity | Mirrors aspired self | Aspiration + belonging |
| Pain | Names exact frustration | Recognition + empathy |
| Contrarian | Challenges held belief | Cognitive dissonance → engagement |
| Validation | Confirms suspicion they had | Relief + trust |
| Social Proof | Crowd signal as opening | Safety in numbers |

### Format Variations
Different structural format = different cognitive decision mode.
Format variations take distribution priority over visual style — they reach different brains, not just different eyes.

| Format | Structure | Cognitive Mode | Best Traffic Type |
|---|---|---|---|
| Problem → Solution | Split: pain / answer | Empathy then relief | Cold |
| Benefits Listicle | Checklist of outcomes | Rational evaluation | Cold |
| Us vs Them | Comparison table | Competitive comparison | Cold |
| Testimonial | One story, specific result | Peer trust | Cold + Retargeting |
| Mechanism | Diagram / flow | Analytical skeptic | Cold |
| Authority | Expert quote + creds | Borrowed credibility | Cold |
| Offer | Product + price + CTA | Transaction-ready | Retargeting |
| Urgency Bundle | Scarcity + value stack | FOMO | Retargeting |
| Guarantee Close | Risk removal dominant | Fear-removal | Retargeting |
| Identity Retargeting | Calls out procrastination | Self-challenge | Retargeting |
| Social Proof Mosaic | Crowd of faces + stats | Mass validation | Retargeting |
| VIP / Exclusivity | Membership framing | Identity confirmation | Retargeting |

---

## STEP 8 — HIGGSFIELD GENERATION

After prompts are output:

```
Ready to generate in Higgsfield?
Tell me how many and I'll run them now.

Defaults:
  Model:  recraft-v4-1
  Ratio:  Per platform assignment above
  Res:    2k

Note: Each variation runs as a separate Higgsfield call.
      If multi-platform, each ratio per variation = separate call.
      e.g., 3 variations × 2 ratios = 6 Higgsfield calls.
```

Present each generated image with: variation name + traffic type + strategic rationale summary + copy direction.
After all images generated, move directly to iteration framework.

---

## STEP 9 — ITERATION DECISION FRAMEWORK

**Fill ALL bracketed placeholders from the research brief before outputting.**
**Never output this block with unfilled placeholders.**
**Every item must be campaign-specific — no generic templates.**

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ITERATION FRAMEWORK — [Brand] [Product]
What To Do After Day 7
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

READ RESULTS IN THIS ORDER:

1. CPM FIRST (Day 2)
   IF CPM > Rs 250: Audience mismatch — not creative issue.
   Fix targeting before touching creative. Kill nothing yet.
   IF CPM < Rs 150: Audience is right. Creative is the variable now.

2. CTR AT DAY 3-4 (Hook winner)
   [Variation A name] vs [Variation B name] vs [Variation C name]
   Highest CTR = hook that resonates.
   → If [primary hook type] wins: buyer is [analytical/trust-driven/etc].
     Next round: 3 new variations using that hook with different formats.
   → If [secondary hook type] wins: buyer responds to [emotion type].
     Next round: test [specific hook suggestion] on same format.
   Kill: CTR < 0.8% after 3 days + 1,000 impressions.

3. CPA AT DAY 7 (Format winner)
   Lowest CPA = format that converts.
   → Scale budget to 70% on winner.
   → [Primary format] winning → test [specific next format] as V[N+1].
   → [Primary format] losing → test [secondary format from brief] next.
   Kill: CPA > Rs [product price × 2] after 14 days + 30 clicks.
   Scale: CPA < Rs [product price × 1] after 7 days.

4. ENGAGEMENT RATE (Visual winner — saves + shares)
   Highest engagement = visual world that connects.
   → Use winning visual style as base for next hook test round.

NEXT ROUND BUILD (campaign-specific):
  Priority 1: [Specific variation to build — format + hook named]
  Priority 2: [Specific variation to build — format + hook named]
  Priority 3: [Specific variation to build — format + hook named]

BUDGET REALLOCATION:
  Day 7:  70% to top 1 performer. 30% to 1 new test.
  Week 3: If top performer ROAS > 1.5x, add [secondary format].
  Week 5: Kill everything below [CPA threshold]. Scale top 2 only.
  Never kill all variations simultaneously — maintain algorithm learning.

RETARGETING TRIGGER:
  Start retargeting when cold traffic pool > 1,000 unique visitors.
  First retargeting format to test: [Testimonial / Guarantee / Offer]
  based on where cold traffic dropped off (page visit vs cart abandon).

PAGE SCALE GATE:
  IF page status was ⚠️ or ⛔:
  Do NOT scale past Rs [2x current daily budget] until these gates pass:
  [List specific failing gates from audit]
  Every rupee spent on a broken page wastes what the ad earned.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## OUTPUT QUALITY CHECKLIST — v4

Run before finalizing output. Every item must pass. No exceptions.

**Pre-Generation**
- [ ] Platform compliance gate passed for ALL planned variations
- [ ] Aspect ratio(s) assigned per platform mapping
- [ ] Traffic type mapping done — cold formats vs retargeting formats confirmed
- [ ] Variation count matches budget tier
- [ ] Distribution confirmed — format minimum (2 per 5+ set) satisfied

**Master Prompt**
- [ ] All RIOA fields populated — zero placeholders
- [ ] Page status + UGC status + budget tier + aspect ratio included
- [ ] Headline options are actual written copy — not directions
- [ ] Visual brief has exact colors, not mood descriptions
- [ ] Compliance note in visual brief

**Each Variation**
- [ ] Traffic type label included (COLD / RETARGETING)
- [ ] Aspect ratio specified correctly for platform
- [ ] Platform compliance check documented per variation
- [ ] Strategic rationale answers ALL 3 questions with labels: Emotion / Mechanism / Difference
- [ ] Higgsfield prompt is 150-200 words (counted — not estimated)
- [ ] Prompt structure: lighting (first 3 sentences) + subject position + background + brand elements + quality cue + "2k"
- [ ] ZERO copy text inside image prompt
- [ ] Multi-ratio: both ratios prompted separately with composition adapted (not just noted)
- [ ] COPY DIRECTION: actual written copy for every field — no directions
- [ ] DESIGN NOTES: ALL FIVE elements present — layout + typography + hierarchy + contrast + compliance
- [ ] UGC note: real quote cited OR composite flagged for replacement
- [ ] Variation is cognitively different from others — different decision mode, not just aesthetics

**Full Set**
- [ ] Cold and retargeting sets labelled separately (if applicable)
- [ ] No two variations share same format AND same hook (duplication)
- [ ] All ⚠️ flags from research brief addressed
- [ ] Iteration framework filled — zero unfilled placeholders
- [ ] Iteration framework is campaign-specific — product price in kill/scale criteria, variation names in CTR/CPA sections, specific next-round builds named

---

## VARIATION COUNTS — v4

| Use Case | Count | Distribution |
|---|---|---|
| Budget < Rs 500/day | 2 | 1 Visual + 1 Format |
| Budget Rs 500-2,000/day | 3 | 1 Visual + 1 Hook + 1 Format |
| Budget Rs 2,000-5,000/day | 5 | 1 Visual + 2 Hook + 2 Format |
| Budget Rs 5,000+/day | 5-10 | Scale formats first |
| Cold + Retargeting | 2 sets | Apply budget rule to each set |
| Full hook test | 6 | Same format, 6 hooks |
| Clone set | 5 | 3 clone executions + 2 original angles |
| Full awareness coverage | 25 | 5 per stage × 5 stages |
| Portfolio showcase | 25 | 5 per stage × 5 sophistication levels |

---

## CONNECTED SKILLS

- **Requires:** `static-ad-research` v4 (full brief with traffic split, page audit, UGC status, budget tier, platform/ratio mapping)
- **Triggers:** Higgsfield image generation via tool call on user confirmation
- **References:** `references/prompt-templates.md` — fill-in templates by format type
- **References:** `references/health-wellness-examples.md` — completed briefs + variations for NOVA Creatine, SHUDH Shilajit, ZIVA Iron, LUMIQ Omega-3
