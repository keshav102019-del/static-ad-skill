# Awareness × Sophistication Framework
## Eugene Schwartz — Applied to Health & Wellness Static Ads

---

## The Two Axes

### Axis 1: Awareness Stage (5 Levels)
How much does the prospect know about their problem and your solution?

| Stage | What They Know | Ad Job |
|---|---|---|
| **Unaware** | Doesn't know the problem exists | Create curiosity / introduce problem |
| **Problem Aware** | Knows the problem, not the solution | Empathize + introduce solution category |
| **Solution Aware** | Knows solutions exist, not your brand | Sell YOUR solution over others |
| **Product Aware** | Knows your brand, hasn't decided | Give final proof / remove objection |
| **Most Aware** | Ready to buy | Make the transaction easy + urgent |

### Axis 2: Market Sophistication (5 Levels)
How saturated is this market with competing claims?

| Level | Market State | What Works |
|---|---|---|
| **1** | New / first movers | Direct benefit claim |
| **2** | Early competition | Problem-solution + differentiation |
| **3** | Claims saturated | Unique mechanism — show HOW it works |
| **4** | Heavy competition | Third-party proof + authority |
| **5** | Hyper saturated | Identity + tribe + contrarian |

---

## Winning Format Matrix

| Awareness Stage | Soph. L1 | Soph. L2 | Soph. L3 | Soph. L4 | Soph. L5 |
|---|---|---|---|---|---|
| **Unaware** | Lifestyle / Curiosity | Shocking Statistic | Contrarian Typography | Identity Aspiration | Community Proof |
| **Problem Aware** | Problem→Solution | Pain Agitation List | Mechanism Education | Authority Quote | Social Proof Cluster |
| **Solution Aware** | Benefits Listicle | Us vs Them | Mechanism Breakdown | Featured Testimonial | Identity Close |
| **Product Aware** | Feature Callout | Before / After | Skeptic Testimonial | Trust + Guarantee | Identity Retargeting |
| **Most Aware** | Direct Offer | Urgency Bundle | Guarantee Close | Social Proof Mosaic | VIP / Exclusivity |

---

## Format Definitions

### CURIOSITY / LIFESTYLE
- Broad scene-setting image with intriguing headline
- No product push — plant a question in the reader's mind
- Works at: Unaware × L1-L2

### SHOCKING STATISTIC
- Hard number that creates personal relevance
- Forces the reader to self-identify as potentially affected
- Works at: Unaware × L2, Problem Aware × L2-L3

### CONTRARIAN / PATTERN INTERRUPT
- Challenges a belief the reader holds
- Provocation that forces engagement
- Works at: Unaware × L3, Solution Aware × L5

### IDENTITY / ASPIRATION
- Shows who the reader wants to become
- Product is secondary — the lifestyle IS the message
- Works at: Unaware × L4-L5, Product Aware × L5

### COMMUNITY PROOF
- Social group + number + belonging signal
- FOMO through tribe, not scarcity
- Works at: Unaware × L5, Most Aware × L4

### PROBLEM → SOLUTION
- Pain on top / answer below (split format)
- Mirrors frustration then redirects to product
- Works at: Problem Aware × L1-L2

### PAIN AGITATION LIST
- Stack 3-5 specific pains as bullet/icon list
- Each line = a "yes" that builds emotional momentum
- Works at: Problem Aware × L2

### MECHANISM EDUCATION
- Infographic-style explanation of WHY the problem happens
- Then shows how product corrects the mechanism
- Works at: Problem Aware × L3, Solution Aware × L3

### AUTHORITY QUOTE
- Expert (doctor, coach, researcher) says what brand would say
- Borrowed credibility bypasses consumer skepticism
- Works at: Problem Aware × L4

### SOCIAL PROOF CLUSTER
- 3 short, specific testimonials with names + timelines
- Peer voices > brand voice at high sophistication
- Works at: Problem Aware × L5

### BENEFITS LISTICLE
- 5-7 checkmark list of what customer gets
- Sets evaluation criteria in buyer's mind
- Works at: Solution Aware × L1

### US VS THEM COMPARISON
- Side-by-side table: your brand vs. "others"
- You control the criteria — and win every row
- Works at: Solution Aware × L2

### MECHANISM BREAKDOWN
- More detailed than education — shows why YOUR mechanism is better
- Eliminates competitors at the molecular/process level
- Works at: Solution Aware × L3

### FEATURED TESTIMONIAL
- One person, one story, specific result with timeline
- Detailed and named — harder to dismiss than aggregate
- Works at: Solution Aware × L4, Product Aware × L3

### TRUST + GUARANTEE
- Shield badge + certification row + refund policy
- Removes risk — only confident brands make this offer
- Works at: Product Aware × L4

### IDENTITY RETARGETING
- Calls out the procrastinating buyer by name
- Uses previous ad exposure as leverage
- Works at: Product Aware × L5

### DIRECT OFFER
- Product + price + CTA — nothing else
- Every extra word is friction at this stage
- Works at: Most Aware × L1

### URGENCY BUNDLE
- Scarcity + value stack + deadline
- Gives qualified buyer a reason to act NOW
- Works at: Most Aware × L2

### GUARANTEE CLOSE
- Zero-risk framing + specific offer + trust badges
- Answers the last objection (what if it doesn't work?)
- Works at: Most Aware × L3

### SOCIAL PROOF MOSAIC
- Grid of customer faces + repeat purchase stat
- Crowd psychology: if this many bought again, it works
- Works at: Most Aware × L4

### VIP / EXCLUSIVITY
- Membership / protocol framing
- Reframes purchase as identity confirmation, not transaction
- Works at: Most Aware × L5

---

## Health & Wellness Specific Notes

### Supplement Market (Creatine, Protein, Pre-workout)
- India sophistication: ~L3-L4 in metro, L2 in tier 2/3
- Primary objection: "Is this safe / will it work for me?"
- Trust signal priority: FSSAI cert > third-party test > reviews > before/after
- Copy register: Direct, punchy, Hinglish-ready for youth audience

### Ayurvedic / Herbal Market (Shilajit, Ashwagandha, Triphala)
- India sophistication: ~L2-L3, rapidly moving to L4 due to fake product flooding
- Primary objection: "Is this real / pure / not adulterated?"
- Trust signal priority: Lab report > source verification > AYUSH > doctor endorsement
- Copy register: Authoritative, educational, reverence for tradition + modern validation

### Skincare / Beauty Wellness
- Higher female audience, identity-driven purchasing
- Sophistication typically L3-L4 in metro India
- Before/after + testimonial combination is strongest format
- Community proof via UGC is extremely high-converting

### Mental Wellness / Sleep
- Problem aware stage most common entry point
- High stigma = indirect problem framing works better than direct
- Lifestyle aspiration angle outperforms problem agitation
- Authority (sleep researcher, therapist) is critical trust builder
