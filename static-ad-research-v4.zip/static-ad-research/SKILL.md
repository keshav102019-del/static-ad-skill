---
name: static-ad-research
description: >
  Health & wellness brand static ad research skill. Use this FIRST and ALWAYS before generating any static ad, winning ad clone, or image prompt for any health, wellness, supplement, Ayurveda, fitness, skincare, or DTC brand. Triggers on: "I want a static", "generate ad", "clone this ad", "create ad for [brand]", "build ad creative", "make a static ad", "ad for my product", "write prompts for ads", or any request involving performance marketing creative for a health/wellness product. This skill runs automatically before the static-ad-generation skill — even if the user doesn't explicitly ask for research. NEVER skip this skill and go straight to generation. A 60% complete brief produces better output than no brief. The research output is the required input for the generation skill.
---

# Static Ad Research Skill — v4

## Purpose
Build a complete, battle-tested **RIOA Research Brief** that feeds directly into `static-ad-generation`. This brief is the strategic foundation. Without it, image prompts produce generic ads. With it, they produce ads built on buyer psychology — and they flag every pre-launch issue that kills campaigns before a single rupee is spent.

## When This Skill Runs
- Automatically before ANY static ad generation request
- When trigger phrases fire (see description above)
- Even when user says "just generate it" — run condensed brief first, then hand off
- Never skipped. Never shortened below minimum viable brief.

---

## STEP 1 — COLLECT INPUTS

Ask for ALL required inputs in ONE structured message. Never ask piecemeal across multiple turns.

```
To build your RIOA Research Brief, I need the following.
Fill in what you know — I'll flag every gap before we proceed.

PRODUCT
□ Brand name + product name
□ Category (supplement / Ayurveda / skincare / fitness / other)
□ Key ingredient or mechanism (what makes it actually work)
□ Features (format, dose, certifications, sourcing, serving size)
□ Core benefits (outcomes the customer gets — not features)
□ Unique differentiator (what no competitor can truthfully claim)
□ Price + current offer + guarantee (if no guarantee, flag immediately)
□ Proof assets (star rating, review count, certifications, studies, UGC)

BUYER
□ Who is the customer? (age, gender, location, income range)
□ What do they deeply want? (outcome, not feature)
□ How long have they had this problem?
□ What have they already tried that failed?
□ What is the ONE belief stopping them from buying right now?
□ Which competitors have they already considered or rejected?

MARKET CONTEXT
□ Platform(s) — list ALL: Instagram / Facebook / Google Display / other
   (multi-platform changes aspect ratio and format recommendations)
□ Market (India metro / India tier 2-3 / Global / specific city)
□ Traffic type(s) — list ALL: cold / warm retargeting / existing customer
   (running both cold + retargeting = separate sophistication briefs needed)
□ Planned daily ad budget (Rs or $) — needed for spend threshold check
□ Do you have any existing customer reviews or UGC you can share?

BRAND
□ Brand aesthetic (colors, tone — premium / bold / minimal / warm / clinical)
□ Any mandatory elements (certifications, logos, specific imagery)
□ Anything to avoid (claims, visuals, competitor mentions)

LANDING PAGE
□ URL of the page the ad will send traffic to
□ What is above the fold on that page right now?
□ Does the page explain the product's unique mechanism?
□ Is the guarantee visible above the fold?
□ Is social proof (reviews/ratings) visible without scrolling?
```

### If Cloning a Winning Ad — Also Collect
```
□ How is the reference ad being provided? (image upload / text description / URL)
□ Which metric proved it won? (CTR / ROAS / conversion rate / CPM / other)
□ How long has it been running? (longevity = proof of performance)
□ What audience was it running to? (cold / warm / lookalike)
```

---

## STEP 2 — TRAFFIC TYPE SPLIT DETECTION (New in v4)

Run this BEFORE sophistication assessment. Traffic type determines whether one brief or two is needed.

```
TRAFFIC TYPE ANALYSIS
━━━━━━━━━━━━━━━━━━━━━
IF campaign runs COLD TRAFFIC ONLY:
  → Single brief. Assess sophistication for cold audience.
  → Awareness stage: Unaware through Solution Aware.
  → Formats: Education-led, mechanism, curiosity, problem-solution.

IF campaign runs RETARGETING ONLY:
  → Single brief. Retargeting audience = Product Aware by definition.
  → Sophistication: Match to cold audience level (they came from same market).
  → Formats: Testimonial, guarantee, offer, urgency, identity close.

IF campaign runs BOTH cold + retargeting simultaneously:
  → TWO separate brief sections required.
  → Cold brief:        Awareness stage per sophistication decision tree below.
  → Retargeting brief: Always Product Aware or Most Aware.
  → Generate separate variation sets for each in generation skill.
  → Never mix cold and retargeting formats in the same ad set.

FLAG: If client says "both" but has limited budget (< Rs 2,000/day):
  → Recommend cold only first. Build retargeting audience before spending
    on retargeting ads. Retargeting pool < 1,000 people = wasted spend.
```

---

## STEP 3 — SOPHISTICATION ASSESSMENT (Internal — Do Before Brief)

Do NOT present as questionnaire. Derive entirely from inputs provided.

### Sophistication Decision Tree

```
Diagnostic questions (answer internally):
1. How many brands making similar claims in this category?
2. Has target audience seen multiple ads for this category before?
3. Is primary buyer objection about the CATEGORY (low soph.)
   or the BRAND (high soph.)?
4. Does buyer use category-specific terminology naturally?
   (e.g., "KSM-66", "micronized", "ferrous bisglycinate", "fulvic acid")
5. What geography? Metro India = higher sophistication than tier 2-3.

Decision:
  New market, no reference point                      → L1
  Few competitors, comparing basic features           → L2
  Claims saturated, skeptical of generic claims       → L3
  Heavy competition, researches before buying,
  has tried alternatives                              → L4
  Hyper-saturated, burned by multiple products,
  identity/tribe is only lever left                   → L5

GEOGRAPHY RULE:
  Mixed metro + tier 2 → assess LOWER level.
  Over-educating a sophisticated buyer costs nothing.
  Under-explaining to an unsophisticated buyer loses the sale.

CONFIDENCE RULE:
  Medium or Low confidence → flag explicitly.
  State: "Assessed L[N] with [confidence]. Would change to L[N±1]
  if [specific information] is confirmed."

COLD VS RETARGETING SOPHISTICATION:
  Cold audience:       Use decision tree above.
  Retargeting audience: Use same L level as cold (same market).
                        But awareness stage is always Product Aware+.
  Do NOT lower sophistication for retargeting — they're more informed,
  not less. They've seen your ads. They know your brand.
```

---

## STEP 4 — GUARANTEE CHECK (Hard Gate)

```
IF brand has NO money-back guarantee:
  → Output and STOP:

  "⛔ GUARANTEE MISSING — RESOLVE BEFORE RUNNING ADS

  Paid ads without a guarantee at L3+ sophistication is budget waste.
  Cold traffic buyers need risk reversal. Without it, you pay to educate
  buyers who then purchase from competitors who offer protection.

  Recommended minimum: 30-day full refund. No forms. No conditions.

  Copy-paste template for your product page:
  'If you don't feel a difference in [X] days, we'll refund every rupee.
   No hoops. No hassle. WhatsApp us: [contact]'

  Once guarantee is live, confirm and I'll proceed.
  If running warm/retargeting traffic ONLY and want to override:
  confirm explicitly — I'll flag it in the brief and document the risk."

Guarantee exists → proceed.
No guarantee + warm override confirmed → proceed with ⛔ in brief. Document once. Do not re-warn.
```

---

## STEP 5 — LANDING PAGE AUDIT

The ad creates desire. The page must close the conversion. If the page breaks what the ad builds, no variation set will save the campaign. Run this before building the brief.

```
GATE 1 — MECHANISM VISIBILITY
  Does the page explain the product's unique mechanism above the fold?
  PASS: Mechanism explained clearly without scrolling.
  FAIL: Mechanism buried or absent → ad education drops off at click.
  Fix: Add one-line mechanism statement in hero copy or subhead.

GATE 2 — GUARANTEE VISIBILITY
  Is the guarantee visible without scrolling on mobile?
  PASS: Guarantee badge or statement in hero section.
  FAIL: Buried in footer → risk reversal fails at point of decision.
  Fix: Add guarantee badge below product CTA button.

GATE 3 — SOCIAL PROOF VISIBILITY
  Are reviews/ratings visible in first scroll?
  PASS: Star rating + review count visible above first scroll.
  FAIL: Reviews absent or below fold → trust gap at conversion moment.
  Fix: Add star rating strip below hero. Even "4.7★ 2,100 reviews" in text.

GATE 4 — OFFER CLARITY
  Is the price, deal, and CTA unmistakably clear?
  PASS: Price visible, CTA button prominent, next step obvious.
  FAIL: Price hidden, CTA weak, flow confusing → friction kills conversion.
  Fix: Make price and CTA button the visual anchor of the hero section.

GATE 5 — CONTINUITY
  Does the page feel like the natural continuation of the ad?
  PASS: Same tone, language, visual identity as the ad.
  FAIL: Scent loss → buyer bounces because it feels like a different brand.
  Fix: Match page headline language to ad headline language exactly.
```

### Audit Output Format

```
LANDING PAGE AUDIT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
URL:               [URL or ⚠️ UNAUDITED]
Gate 1 Mechanism:  [PASS / FAIL / UNKNOWN] — [note + specific fix]
Gate 2 Guarantee:  [PASS / FAIL / UNKNOWN] — [note + specific fix]
Gate 3 Proof:      [PASS / FAIL / UNKNOWN] — [note + specific fix]
Gate 4 Offer:      [PASS / FAIL / UNKNOWN] — [note + specific fix]
Gate 5 Continuity: [PASS / FAIL / UNKNOWN] — [note + specific fix]

0 FAILs  → ✅ PAGE READY
1 FAIL   → ⚠️ PAGE WEAKNESS — fix before scaling spend
2+ FAILs → ⛔ PAGE NOT READY — fix before running any paid traffic

If 2+ FAILs: list ALL specific fixes. Do not proceed to generation
until client confirms fixes are live OR explicitly overrides for planning.
```

---

## STEP 6 — SPEND THRESHOLD GUIDANCE

Output before building brief. Budget determines variation count and test window.

```
SPEND THRESHOLD ANALYSIS
━━━━━━━━━━━━━━━━━━━━━━━━
Statistical significance requires 50 conversions per variation minimum.
Target CPA = product price × 1.5 (acceptable acquisition cost).

Budget tiers (India Meta, cold traffic):
  < Rs 500/day:        2 variations max. Run 30+ days minimum.
  Rs 500-2,000/day:    3 variations max. Run 14-21 days minimum.
  Rs 2,000-5,000/day:  5 variations. Run 10-14 days minimum.
  Rs 5,000+/day:       5-10 variations. Run 7-10 days minimum.
  Budget UNKNOWN:      Default to 3 variations. Flag assumption.

Kill criteria (fill with product price):
  Kill if CTR < 0.8% after 3 days + 1,000 impressions.
  Kill if CPA > [product price × 2] after 14 days + 30 clicks.
  Kill if CPM > Rs 250 after 2 days — audience mismatch, not creative issue.
  Scale if CPA < [product price × 1] after 7 days — profitable.

Budget risk flags:
  IF budget < Rs 1,000/day AND no guarantee: ⛔ Do not run cold traffic.
  IF retargeting pool < 1,000 people: ⛔ Do not run retargeting yet.
  IF page has 2+ FAILs: ⛔ Every rupee spent is partially wasted.
```

---

## STEP 7 — UGC AUDIT & COLLECTION BRIEF (New in v4)

Run when testimonial or social proof formats are in the winning format list OR when UGC status is unknown.

```
UGC AUDIT
━━━━━━━━━
IF client has existing reviews / UGC:
  → Ask: "Share 3-5 of your best reviews — specifically ones that
    mention the problem they had before, and what changed after.
    We'll use the exact language in ad copy."
  → Mine for: specific problem language, timeline ("week 3"), third-party
    observations ("my husband noticed"), objection-handling ("I was
    skeptical but..."), mechanism reference ("the X made the difference").

IF client has NO reviews / UGC (< 50 reviews or no customer content):
  → Output UGC COLLECTION BRIEF:

  "⚠️ UGC GAP — Testimonial format ads need real customer content.
   Before running testimonial format variations, collect the following:

   UGC COLLECTION BRIEF:
   ─────────────────────
   Ask your existing customers (WhatsApp / email / post-purchase survey):

   Question 1: 'Before you tried [product], what was the main thing
   bothering you? How long had it been going on?'
   (Captures: problem + duration — exact language for pain agitation ads)

   Question 2: 'What made you skeptical before buying?'
   (Captures: objection in buyer's voice — for skeptic testimonial format)

   Question 3: 'When did you first notice a difference? What changed?'
   (Captures: timeline + specific result — for testimonial copy)

   Question 4: 'Did anyone else notice the change before you did?'
   (Captures: third-party observation — most credible testimonial element)

   Question 5: 'What would you tell someone who is where you were 3 months ago?'
   (Captures: peer-to-peer recommendation language — direct ad copy)

   Aim: 5-10 responses. Even 3 specific responses outperform 100 generic ones.
   Proceed with testimonial format only after collecting at least 3 responses."

IF proceeding without UGC:
  → Use composite testimonial (synthesized from category review patterns).
  → Flag in brief: ⚠️ COMPOSITE TESTIMONIAL — replace with real customer
    quote before scaling spend on testimonial variation.
```

---

## STEP 8 — MULTI-PLATFORM ASPECT RATIO MAPPING (New in v4)

Run when client specifies more than one platform.

```
PLATFORM → ASPECT RATIO MAP
━━━━━━━━━━━━━━━━━━━━━━━━━━━
Instagram Feed:       4:5  (optimal mobile feed)
Instagram Story/Reel: 9:16
Instagram Square:     1:1  (lower performance than 4:5)
Facebook Feed:        1:1  (optimal for FB feed)
Facebook Story:       9:16
Google Display:       1:1, 4:3, 16:9 (provide all three)
YouTube Thumbnail:    16:9

MULTI-PLATFORM RULE:
  If campaign runs on Instagram AND Facebook feed:
    → Generate 4:5 version (Instagram) AND 1:1 version (Facebook).
    → Same copy and strategy. Different crop only.
    → Note in generation handoff: "Two aspect ratios needed per variation."

  If campaign runs feed AND stories:
    → Feed: 4:5 (Instagram) or 1:1 (Facebook).
    → Stories: 9:16 with text in center-safe zone (top/bottom 20% cut off).
    → Stories need shorter copy — 3 seconds to stop scroll.
    → Note in generation handoff: "Stories need separate prompt — shorter copy."

  Single platform → use platform's optimal ratio. No flag needed.
```

---

## STEP 9 — BUILD THE RIOA BRIEF

All gates above must be run before this step. Build the full brief now.

---

### 📋 RIOA RESEARCH BRIEF — v4

**Brand:** [Name]
**Product:** [Name]
**Category:** [Category]
**Platform(s):** [All platforms — aspect ratio implications noted]
**Market:** [Region + traffic type]
**Daily Budget:** [Rs/$ + variation count derived]
**Brief Type:** [Single / Dual (cold + retargeting)]
**Brief Date:** [Date]

---

#### R — READER

| Dimension | Detail |
|---|---|
| **Demographics** | Age, gender, income, location — specific |
| **Desires** | Deep outcome — the feeling/result, not the feature |
| **Notions** | What they already believe about this category BEFORE seeing the ad |
| **Characteristics** | Content consumed, platforms used, who they trust |
| **Identity** | How they see themselves AND how they want to be seen |
| **Problem Duration** | Weeks / months / years — matters for urgency vs education tone |
| **Failed Attempts** | What they tried that didn't work — specific brands or methods |
| **Core Objection** | ONE belief stopping purchase — stated in buyer's exact words |
| **Competitor Awareness** | Brands seen / tried / rejected — with reason if known |

**Rule:** Every row filled from inference → mark ⚠️ ASSUMED + state assumption + state what changes if wrong.

---

#### I — IDENTIFICATION & ANGLE

| Dimension | Detail |
|---|---|
| **Reader Self-Image** | How this buyer identifies right now |
| **Aspired Identity** | Who they want to become — outcome identity, not demographic |
| **Best Creative Angle** | Single strategic angle bridging current → aspired identity via product |
| **Emotional Trigger** | ONE: aspiration / frustration / pride / fear / belonging / curiosity / validation |
| **Tone Register** | peer / authoritative / educational / aspirational / contrarian |
| **What to Avoid** | Tones or angles that repel this specific buyer |

---

#### O — OFFER

| Dimension | Detail |
|---|---|
| **Core Offer** | Exactly what is sold — format, quantity, serving |
| **Price / Deal** | Exact price + any active discount or bundle |
| **Guarantee** | Exact terms — or ⛔ MISSING |
| **Proof Stack** | Stars + review count + certs + studies + UGC — exact numbers |
| **Unique Mechanism** | The HOW it works differently — not the WHAT |
| **Differentiator** | What no competitor can truthfully claim — verifiable, specific |
| **Offer Gap Flags** | What's missing that hurts conversion |

---

#### A — ACTION

| Dimension | Detail |
|---|---|
| **Desired Action** | Exactly what to do after seeing the ad |
| **CTA Tone** | urgent / soft / exclusive / educational-then-direct / curiosity |
| **Funnel Stage** | Cold / Warm retargeting / Existing customer |
| **Landing Destination** | URL + what's above fold |
| **Page Audit Result** | ✅ READY / ⚠️ WEAKNESS (Gate N) / ⛔ NOT READY (Gates N, N) |
| **Friction Points** | Specific elements on page that kill the conversion the ad earned |

---

#### AWARENESS × SOPHISTICATION POSITION

```
── COLD TRAFFIC BRIEF ──────────────────────────────────

Awareness Stage:       [Stage]
Sophistication Level:  [L1-L5]
Sophistication Source: [Geography + competitive landscape + buyer signals]
Confidence:            [High / Medium / Low + resolution note if not High]

Competitive Context:
  Competitors seen:     [List]
  Competitors rejected: [List + reason]
  Overused claims:      [What NOT to say — saturated in this category]

Winning Formats (Cold):
  Primary:   [Format]
  Secondary: [Format]
  Tertiary:  [Format]

Strategic Rationale:
  [WHY this stage × sophistication. Which signals drove it.
   What changes the assessment if a key assumption is wrong.]

── RETARGETING BRIEF (only if running retargeting) ─────

Awareness Stage:       Product Aware / Most Aware
Sophistication Level:  [Same L as cold — same market, more informed]
Traffic Profile:       [Visited product page / added to cart / past buyer]

Winning Formats (Retargeting):
  Primary:   [Testimonial / Guarantee / Offer / Identity Retargeting]
  Secondary: [Format based on where in funnel they dropped]
  Tertiary:  [Format]

Retargeting Angle:
  [What specific action did they take before dropping off?
   Cart abandon → urgency + guarantee.
   Page visit only → social proof + mechanism reminder.
   Past buyer → upsell / repurchase / loyalty angle.]
```

---

#### PRODUCT INTELLIGENCE

```
Mechanism:         [How it works — scientific or clinical explanation]
Hero Ingredient:   [Name + why it matters + what separates from generic]
Features:          [Top 3-5 — specific, not vague]
Benefits:          [Top 3-5 — outcomes the customer gets]
Proof:             [Exact: X stars, Y reviews, Z certs, N studies]
Differentiator:    [One verifiable claim no competitor can match]
Claim Limits:      [What CANNOT be claimed — regulatory, platform, ethical]
UGC Status:        [Available / Needed / Collection brief issued]
Best Review Quote: [Exact quote from real customer if available — for testimonial format]
```

---

#### CLONE ANALYSIS (only if cloning)

```
Reference Source:    [Image / URL / description]
Performance Proof:   [Winning metric + duration running]
Original Audience:   [Who it targeted — cold / warm / specific demo]

Reverse Engineering:
  Format:            [Structural format]
  Awareness Pos:     [Stage × Soph. of original]
  Hook Type:         [Opening psychological mechanism]
  Visual Strategy:   [WHY the image works — not what it shows]
  Copy Strategy:     [What the headline is doing psychologically]
  Emotional Arc:     [First impression → engagement → CTA feeling]
  Why It Wins:       [Specific psychological lever — not "it's relatable"]

Clone Strategy:
  Keep:    [Format logic, hook type, emotional arc, layout structure]
  Adapt:   [Brand identity, proof, mechanism language, cultural context]
  Upgrade: [Where original is weak — improve here]
  Risk:    [What breaks when transplanting to new brand]
```

---

#### CREATIVE CONSTRAINTS

```
Brand Aesthetic:     [Specific palette + visual tone]
Mandatory Elements:  [Must-appear items with exact placement]
Hard Avoids:         [Claims, imagery, tones — regulatory or strategic]

PLATFORM COMPLIANCE:
  Meta (Instagram/Facebook):
    ✗ No before/after body transformation images
    ✗ No medical cure / treatment language
    ✗ No fear-based body image language
    ✗ Testimonials require "Results may vary" disclaimer
    ✓ Lifestyle imagery — OK
    ✓ Clinical study references (not disease-cure framing) — OK
    ✓ Social proof with disclaimer — OK

  Google Display:
    ✗ No sensational / shocking imagery
    ✗ No misleading health claims
    ✓ Educational framing preferred

ASPECT RATIO REQUIREMENTS (from platform mapping):
  [Platform A] → [ratio]
  [Platform B] → [ratio — if different, note separate prompts needed]
```

---

#### UGC STATUS & BRIEF

```
UGC Available:       [Yes / No / Unknown]
Best Quotes:         [Top 3 review quotes with problem + result language]
Collection Brief:    [Issued / Not needed]
Testimonial Ready:   [Yes — use real quote / No — use composite + flag]
```

---

#### GAPS & FLAGS SUMMARY

```
⛔ HARD STOPS (resolve before running ads):
   [Each stop on its own line — specific, not generic]

⚠️ SOFT GAPS (assumptions — proceed but account for in generation):
   [Each assumption + what changes if wrong]

💡 STRATEGIC RECOMMENDATIONS (improvements before scaling):
   [Specific, actionable — referencing this brand's exact situation]

SPEND THRESHOLD SUMMARY:
   Daily budget:        [Rs/$ confirmed or UNKNOWN]
   Variation count:     [N — derived from budget tier]
   Kill criteria:       [CTR threshold / CPA threshold / window]
   Scale criteria:      [CPA threshold for profitable scaling]
   Budget risk note:    [Specific risk for this brand's current offer state]
```

---

## STEP 10 — VALIDATE BEFORE HANDOFF

Internal checklist — ALL must pass before handoff:

- [ ] Traffic type split detected — single or dual brief confirmed
- [ ] All 4 RIOA components fully filled — zero placeholders
- [ ] Cold sophistication assessed with rationale + confidence level
- [ ] Retargeting section completed (if applicable)
- [ ] Guarantee check passed or hard-stop issued
- [ ] Landing page audit completed — all 5 gates assessed
- [ ] Spend threshold guidance output with kill + scale criteria
- [ ] UGC audit run — status documented, collection brief issued if needed
- [ ] Multi-platform aspect ratio mapping completed
- [ ] Problem duration captured (specific not "some time")
- [ ] Failed attempts specific — named methods or brands
- [ ] Core objection in buyer's exact voice — not paraphrased
- [ ] Competitor landscape captured — seen / tried / rejected + reason
- [ ] Platform compliance rules noted with specifics
- [ ] All assumptions flagged ⚠️ with rationale + resolution condition
- [ ] Gaps in 3-tier format complete
- [ ] If cloning — clone analysis fully complete including why it wins

---

## STEP 11 — HANDOFF TO GENERATION SKILL

```
✅ RIOA Research Brief v4 Complete
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Brand:              [Brand Name]
Product:            [Product Name]
Stage × Soph:       Cold: [Stage] × L[N] | Retargeting: [Stage] × L[N]
Primary Format:     Cold: [Format] | Retargeting: [Format]
Key Angle:          [Creative angle in one line]
Platforms:          [List] → Aspect ratios: [List]
Page Status:        [✅ READY / ⚠️ WEAKNESS / ⛔ NOT READY]
Budget Tier:        [Rs/day] → [N] variations
UGC Status:         [Ready / Composite / Collection brief issued]
Critical Flags:     [All ⛔ items]
Soft Flags:         [All ⚠️ items carried to generation]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Passing to static-ad-generation skill.
```

---

## EDGE CASES

**"Just generate it, skip research"**
→ Never skip. Build condensed brief from context. Flag all assumptions explicitly. State count: "Running condensed brief — [N] assumptions made." Hand off with flags.

**Partial client input**
→ Fill from context + category knowledge. Flag every inference ⚠️. Silent wrong assumption > flagged assumption.

**Cloning — image provided**
→ Analyze visually FIRST. Identify format, hook, layout logic, emotional arc, awareness stage from observation. Fill clone analysis before any generation.

**No guarantee, client overrides**
→ Issue hard-stop once. If override confirmed, proceed with ⛔ flag. Do not re-warn in same session.

**Sophistication unclear**
→ Default LOWER. Flag uncertainty. State what information resolves it.

**Landing page URL unavailable**
→ Flag entire audit ⚠️ UNAUDITED. All 5 gates UNKNOWN. Proceed noting: "Ad performance depends on page quality we cannot assess. Review page before scaling."

**Budget not provided**
→ Flag UNKNOWN. Default to 3 variations. Ask client to confirm before finalizing.

**Mixed cold + retargeting, limited budget**
→ Recommend cold only first. Build retargeting pool before spending retargeting budget. Flag if retargeting pool < 1,000 people.

**No UGC available**
→ Issue collection brief. Use composite testimonial for planning. Flag for replacement with real quote before scaling.

---

## REFERENCE FILES
- `references/awareness-framework.md` — Full Schwartz matrix, winning formats per position, health/wellness category notes
